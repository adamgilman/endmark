import{$n}from"./chunk-wszrcpxc.js";export{$n as createInfoServices};
