import{Un}from"./chunk-wszrcpxc.js";export{Un as createArchitectureServices};
