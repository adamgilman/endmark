import{zn}from"./chunk-wszrcpxc.js";export{zn as createPacketServices};
