import{e}from"./chunk-bdqnwth2.js";var gt=class{constructor(t){this.init=t,this.records=this.init()}static{e(this,"ImperativeState")}reset(){this.records=this.init()}};
export{gt};
