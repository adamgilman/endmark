import{Un}from"./chunk-dtn33v35.js";export{Un as createArchitectureServices};
