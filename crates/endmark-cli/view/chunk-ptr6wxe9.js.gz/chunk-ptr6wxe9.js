import{e,t,Z,u,E,S,d,r,_}from"./chunk-bdqnwth2.js";var O="",W="",B="",Y=[],A=new Map,y=e((i)=>E(i,r()),"sanitizeText"),b=e((i)=>{switch(i.type){case"terminal":return{...i,value:y(i.value)};case"nonterminal":return{...i,name:y(i.name)};case"sequence":return{...i,elements:i.elements.map(b)};case"choice":return{...i,alternatives:i.alternatives.map(b)};case"optional":return{...i,element:b(i.element)};case"repetition":return{...i,element:b(i.element),separator:i.separator?b(i.separator):void 0};case"special":return{...i,text:y(i.text)}}},"sanitizeAstNode"),j=e(()=>{O="",W="",B="",Y.length=0,A.clear(),d(),t.debug("[Railroad] Database cleared")},"clear"),X=e((i)=>{O=y(i),t.debug("[Railroad] Title set:",i)},"setTitle"),H=e(()=>O,"getTitle"),K=e((i)=>{let o={...i,name:y(i.name),definition:b(i.definition),comment:i.comment?y(i.comment):void 0};if(t.debug("[Railroad] Adding rule:",o.name),A.has(o.name))t.warn(`[Railroad] Rule '${o.name}' is already defined. Overwriting.`);Y.push(o),A.set(o.name,o)},"addRule"),J=e(()=>Y,"getRules"),Q=e((i)=>A.get(i),"getRule"),V=e((i)=>{W=y(i).replace(/^\s+/g,""),t.debug("[Railroad] Accessibility title set:",i)},"setAccTitle"),ee=e(()=>W,"getAccTitle"),te=e((i)=>{B=y(i).replace(/\n\s+/g,`
`),t.debug("[Railroad] Accessibility description set:",i)},"setAccDescription"),re=e(()=>B,"getAccDescription"),ie=X,ne=H,D={clear:j,setTitle:X,getTitle:H,addRule:K,getRules:J,getRule:Q,setAccTitle:V,getAccTitle:ee,setAccDescription:te,getAccDescription:re,setDiagramTitle:ie,getDiagramTitle:ne},w={compactMode:!1,padding:10,verticalSeparation:8,horizontalSeparation:10,arcRadius:10,fontSize:14,fontFamily:"monospace",terminalFill:"#FFFFC0",terminalStroke:"#000000",terminalTextColor:"#000000",nonTerminalFill:"#FFFFFF",nonTerminalStroke:"#000000",nonTerminalTextColor:"#000000",lineColor:"#000000",strokeWidth:2,markerFill:"#000000",commentFill:"#E8E8E8",commentStroke:"#888888",commentTextColor:"#666666",specialFill:"#F0E0FF",specialStroke:"#8800CC",ruleNameColor:"#000066",showMarkers:!0,markerRadius:5},ae=/^#(?:[\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})$|^(?:rgb|rgba|hsl|hsla|hwb|lab|lch|oklab|oklch)\([\d\s%+,./-]+\)$|^[a-z]+$/i,oe=/^[\w "',.-]+$/,le=new Set(["compactMode","padding","verticalSeparation","horizontalSeparation","arcRadius","fontSize","fontFamily","terminalFill","terminalStroke","terminalTextColor","nonTerminalFill","nonTerminalStroke","nonTerminalTextColor","lineColor","strokeWidth","markerFill","commentFill","commentStroke","commentTextColor","specialFill","specialStroke","ruleNameColor","showMarkers","markerRadius"]),q=e((i)=>{if(!i)return!1;return Object.keys(i).every((o)=>o==="railroad"||le.has(o))},"isRailroadStyleOptions"),se=e((i)=>{if(!i)return{};if("railroad"in i&&i.railroad)return i.railroad;return q(i)?i:{}},"extractRailroadOverrides"),de=e((i)=>{if(!i||q(i))return{};let{railroad:o,svgId:s,theme:a,look:n,...l}=i;return l},"extractThemeOverrides"),f=e((i,o)=>{if(typeof i!=="string")return o;let s=i.trim();return ae.test(s)?s:o},"sanitizeColorValue"),G=e((i,o)=>{if(typeof i!=="string")return o;let s=i.trim();return oe.test(s)?s:o},"sanitizeFontFamilyValue"),z=e((i,o)=>{let s=typeof i==="number"?i:typeof i==="string"?Number.parseFloat(i):Number.NaN;return Number.isFinite(s)&&s>=0?s:o},"sanitizeNumberValue"),ce=e((i)=>{let o=typeof i==="number"?i:typeof i==="string"?Number.parseFloat(i):Number.NaN;return Number.isFinite(o)&&o>0?o:void 0},"parseThemeFontSize"),me=e((i)=>{let o=G(i.fontFamily,w.fontFamily),s=ce(i.fontSize)??w.fontSize;return{...w,fontFamily:o,fontSize:s,terminalFill:f(i.secondBkg??i.secondaryColor,w.terminalFill),terminalStroke:f(i.secondaryBorderColor??i.lineColor,w.terminalStroke),terminalTextColor:f(i.secondaryTextColor??i.textColor,w.terminalTextColor),nonTerminalFill:f(i.mainBkg??i.background,w.nonTerminalFill),nonTerminalStroke:f(i.primaryBorderColor??i.lineColor,w.nonTerminalStroke),nonTerminalTextColor:f(i.primaryTextColor??i.textColor,w.nonTerminalTextColor),lineColor:f(i.lineColor,w.lineColor),markerFill:f(i.lineColor,w.markerFill),commentFill:f(i.labelBackground??i.tertiaryColor,w.commentFill),commentStroke:f(i.tertiaryBorderColor??i.lineColor,w.commentStroke),commentTextColor:f(i.tertiaryTextColor??i.textColor,w.commentTextColor),specialFill:f(i.tertiaryColor??i.secondaryColor,w.specialFill),specialStroke:f(i.tertiaryBorderColor??i.secondaryBorderColor,w.specialStroke),ruleNameColor:f(i.titleColor??i.textColor,w.ruleNameColor)}},"buildThemeDefaults"),P=e((i)=>{let o=u(),s={...Z(),...o.themeVariables??{},...de(i)},a=me(s),n={...o.railroad??{},...se(i)};return{compactMode:n.compactMode??a.compactMode,padding:z(n.padding,a.padding),verticalSeparation:z(n.verticalSeparation,a.verticalSeparation),horizontalSeparation:z(n.horizontalSeparation,a.horizontalSeparation),arcRadius:z(n.arcRadius,a.arcRadius),fontSize:z(n.fontSize,a.fontSize),fontFamily:G(n.fontFamily,a.fontFamily),terminalFill:f(n.terminalFill,a.terminalFill),terminalStroke:f(n.terminalStroke,a.terminalStroke),terminalTextColor:f(n.terminalTextColor,a.terminalTextColor),nonTerminalFill:f(n.nonTerminalFill,a.nonTerminalFill),nonTerminalStroke:f(n.nonTerminalStroke,a.nonTerminalStroke),nonTerminalTextColor:f(n.nonTerminalTextColor,a.nonTerminalTextColor),lineColor:f(n.lineColor,a.lineColor),strokeWidth:z(n.strokeWidth,a.strokeWidth),markerFill:f(n.markerFill,a.markerFill),commentFill:f(n.commentFill,a.commentFill),commentStroke:f(n.commentStroke,a.commentStroke),commentTextColor:f(n.commentTextColor,a.commentTextColor),specialFill:f(n.specialFill,a.specialFill),specialStroke:f(n.specialStroke,a.specialStroke),ruleNameColor:f(n.ruleNameColor,a.ruleNameColor),showMarkers:n.showMarkers??a.showMarkers,markerRadius:z(n.markerRadius,a.markerRadius)}},"buildRailroadStyleOptions"),je=e((i)=>{let{fontFamily:o,fontSize:s,terminalFill:a,terminalStroke:n,terminalTextColor:l,nonTerminalFill:T,nonTerminalStroke:h,nonTerminalTextColor:c,lineColor:x,strokeWidth:g,markerFill:p,commentFill:v,commentStroke:m,commentTextColor:C,specialFill:N,specialStroke:R,ruleNameColor:F}=P(i);return`
  .railroad-diagram {
    font-family: ${o};
    font-size: ${s}px;
  }

  .railroad-terminal rect {
    fill: ${a};
    stroke: ${n};
    stroke-width: ${g}px;
  }

  .railroad-terminal text {
    fill: ${l};
    font-family: ${o};
    font-size: ${s}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-nonterminal rect {
    fill: ${T};
    stroke: ${h};
    stroke-width: ${g}px;
  }

  .railroad-nonterminal text {
    fill: ${c};
    font-family: ${o};
    font-size: ${s}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-line {
    stroke: ${x};
    stroke-width: ${g}px;
    fill: none;
  }

  .railroad-start circle,
  .railroad-end circle {
    fill: ${p};
  }

  .railroad-comment ellipse {
    fill: ${v};
    stroke: ${m};
    stroke-width: ${g}px;
  }

  .railroad-comment text {
    fill: ${C};
    font-style: italic;
    font-family: ${o};
    font-size: ${s}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-special rect {
    fill: ${N};
    stroke: ${R};
    stroke-width: ${g}px;
    stroke-dasharray: 5,3;
  }

  .railroad-special text {
    fill: ${c};
    font-family: ${o};
    font-size: ${s}px;
    text-anchor: middle;
    dominant-baseline: middle;
  }

  .railroad-rule-name {
    font-weight: bold;
    fill: ${F};
    font-family: ${o};
    font-size: ${s}px;
  }

  .railroad-group {
    /* Grouping container, no specific styles */
  }
`},"getStyles"),k=class{constructor(){this.d=""}static{e(this,"PathBuilder")}moveTo(i,o){return this.d+=`M ${i} ${o} `,this}lineTo(i,o){return this.d+=`L ${i} ${o} `,this}horizontalTo(i){return this.d+=`H ${i} `,this}verticalTo(i){return this.d+=`V ${i} `,this}arcTo(i,o,s,a,n,l,T){return this.d+=`A ${i} ${o} ${s} ${a?1:0} ${n?1:0} ${l} ${T} `,this}build(){return this.d.trim()}},he=class{constructor(i,o=P()){this.textCache=new Map,this.svg=i,this.config=o}static{e(this,"RailroadRenderer")}measureText(i){if(this.textCache.has(i))return this.textCache.get(i);let o=this.svg.append("text").attr("font-family",this.config.fontFamily).attr("font-size",this.config.fontSize).text(i),s=o.node().getBBox(),a={width:s.width,height:s.height};return o.remove(),this.textCache.set(i,a),a}renderTerminal(i,o){let s=this.measureText(o),a=s.width+this.config.padding*2,n=s.height+this.config.padding*2,l=i.append("g").attr("class","railroad-terminal");return l.append("rect").attr("x",0).attr("y",0).attr("width",a).attr("height",n).attr("rx",10).attr("ry",10),l.append("text").attr("x",a/2).attr("y",n/2).text(o),{element:l.node(),dimensions:{width:a,height:n,up:n/2,down:n/2}}}renderNonTerminal(i,o){let s=this.measureText(o),a=s.width+this.config.padding*2,n=s.height+this.config.padding*2,l=i.append("g").attr("class","railroad-nonterminal");return l.append("rect").attr("x",0).attr("y",0).attr("width",a).attr("height",n),l.append("text").attr("x",a/2).attr("y",n/2).text(o),{element:l.node(),dimensions:{width:a,height:n,up:n/2,down:n/2}}}renderSequence(i,o){let s=o.map((c)=>this.renderExpression(i,c)),a=0,n=0,l=0;for(let c of s)a+=c.dimensions.width,n=Math.max(n,c.dimensions.up),l=Math.max(l,c.dimensions.down);a+=(s.length-1)*this.config.horizontalSeparation;let T=i.append("g").attr("class","railroad-sequence"),h=0;for(let c=0;c<s.length;c++){let x=s[c],g=n-x.dimensions.up;if(T.node().appendChild(x.element).setAttribute("transform",`translate(${h}, ${g})`),c<s.length-1){let v=h+x.dimensions.width,m=v+this.config.horizontalSeparation,C=n;T.append("path").attr("class","railroad-line").attr("d",new k().moveTo(v,C).lineTo(m,C).build())}h+=x.dimensions.width+this.config.horizontalSeparation}return{element:T.node(),dimensions:{width:a,height:n+l,up:n,down:l}}}renderChoice(i,o){let s=o.map((p)=>this.renderExpression(i,p)),a=0,n=0;for(let p of s)a=Math.max(a,p.dimensions.width),n+=p.dimensions.height;n+=(s.length-1)*this.config.verticalSeparation;let l=this.config.arcRadius,T=l*4,h=a+T,c=i.append("g").attr("class","railroad-choice"),x=0,g=n/2;for(let p of s){let v=x,m=v+p.dimensions.up,C=l*2+(a-p.dimensions.width)/2;c.node().appendChild(p.element).setAttribute("transform",`translate(${C}, ${v})`);let R=new k,F=m>g;if(m===g)R.moveTo(0,g).lineTo(C,m);else R.moveTo(0,g).arcTo(l,l,0,!1,F,l,g+(F?l:-l)).lineTo(l,m-(F?l:-l)).arcTo(l,l,0,!1,!F,l*2,m).lineTo(C,m);c.append("path").attr("class","railroad-line").attr("d",R.build());let M=new k,L=C+p.dimensions.width,U=h-l*2;if(m===g)M.moveTo(L,m).lineTo(h,g);else M.moveTo(L,m).lineTo(U,m).arcTo(l,l,0,!1,!F,h-l,m+(F?-l:l)).lineTo(h-l,g+(F?l:-l)).arcTo(l,l,0,!1,F,h,g);c.append("path").attr("class","railroad-line").attr("d",M.build()),x+=p.dimensions.height+this.config.verticalSeparation}return{element:c.node(),dimensions:{width:h,height:n,up:g,down:n-g}}}renderOptional(i,o){let s=this.renderExpression(i,o),a=this.config.arcRadius,n=a*2,l=s.dimensions.width+a*4,T=s.dimensions.height+n,h=i.append("g").attr("class","railroad-optional"),c=a*2,x=n;h.node().appendChild(s.element).setAttribute("transform",`translate(${c}, ${x})`);let p=x+s.dimensions.up,v=new k().moveTo(0,p).lineTo(a*2,p);h.append("path").attr("class","railroad-line").attr("d",v.build());let m=new k().moveTo(c+s.dimensions.width,p).lineTo(l,p);h.append("path").attr("class","railroad-line").attr("d",m.build());let C=new k().moveTo(0,p).arcTo(a,a,0,!1,!1,a,p-a).lineTo(a,a).arcTo(a,a,0,!1,!0,a*2,0).lineTo(l-a*2,0).arcTo(a,a,0,!1,!0,l-a,a).lineTo(l-a,p-a).arcTo(a,a,0,!1,!1,l,p);return h.append("path").attr("class","railroad-line").attr("d",C.build()),{element:h.node(),dimensions:{width:l,height:T,up:p,down:T-p}}}renderRepetition(i,o,s){let a=this.renderExpression(i,o),n=this.config.arcRadius,l=n*2,T=a.dimensions.width+n*4,h=s===0,c=a.dimensions.height+l+(h?l:0),x=i.append("g").attr("class","railroad-repetition"),g=n*2,p=h?l:0;x.node().appendChild(a.element).setAttribute("transform",`translate(${g}, ${p})`);let m=p+a.dimensions.up;x.append("path").attr("class","railroad-line").attr("d",new k().moveTo(0,m).lineTo(n*2,m).build()),x.append("path").attr("class","railroad-line").attr("d",new k().moveTo(g+a.dimensions.width,m).lineTo(T,m).build());let C=p+a.dimensions.height+n,N=new k().moveTo(g+a.dimensions.width,m).arcTo(n,n,0,!1,!0,g+a.dimensions.width+n,m+n).lineTo(g+a.dimensions.width+n,C).arcTo(n,n,0,!1,!0,g+a.dimensions.width,C+n).lineTo(n*2,C+n).arcTo(n,n,0,!1,!0,n,C).lineTo(n,m+n).arcTo(n,n,0,!1,!0,n*2,m);if(x.append("path").attr("class","railroad-line").attr("d",N.build()),h){let R=new k().moveTo(0,m).arcTo(n,n,0,!1,!1,n,m-n).lineTo(n,n).arcTo(n,n,0,!1,!0,n*2,0).lineTo(T-n*2,0).arcTo(n,n,0,!1,!0,T-n,n).lineTo(T-n,m-n).arcTo(n,n,0,!1,!1,T,m);x.append("path").attr("class","railroad-line").attr("d",R.build())}return{element:x.node(),dimensions:{width:T,height:c,up:m,down:c-m}}}renderSpecial(i,o){let s=this.measureText("? "+o+" ?"),a=s.width+this.config.padding*2,n=s.height+this.config.padding*2,l=i.append("g").attr("class","railroad-special");return l.append("rect").attr("x",0).attr("y",0).attr("width",a).attr("height",n),l.append("text").attr("x",a/2).attr("y",n/2).text("? "+o+" ?"),{element:l.node(),dimensions:{width:a,height:n,up:n/2,down:n/2}}}renderExpression(i,o){switch(o.type){case"terminal":return this.renderTerminal(i,o.value);case"nonterminal":return this.renderNonTerminal(i,o.name);case"sequence":return this.renderSequence(i,o.elements);case"choice":return this.renderChoice(i,o.alternatives);case"optional":return this.renderOptional(i,o.element);case"repetition":return this.renderRepetition(i,o.element,o.min);case"special":return this.renderSpecial(i,o.text);default:throw Error(`Unknown node type: ${o.type}`)}}renderRule(i,o){let s=this.svg.append("g").attr("class","railroad-rule").attr("transform",`translate(0, ${o})`),a=i.name+" =",n=this.measureText(a).width+20,l=n+20,T=s.append("g"),h=this.renderExpression(T,i.definition),c=Math.max(20,h.dimensions.up),x=c-h.dimensions.up;return T.attr("transform",`translate(${l}, ${x})`),s.append("g").attr("class","railroad-rule-name-group").append("text").attr("class","railroad-rule-name").attr("x",0).attr("y",c).text(a),s.append("g").attr("class","railroad-start").append("circle").attr("cx",n).attr("cy",c).attr("r",this.config.markerRadius),s.append("g").attr("class","railroad-end").append("circle").attr("cx",l+h.dimensions.width+10).attr("cy",c).attr("r",this.config.markerRadius),s.append("path").attr("class","railroad-line").attr("d",new k().moveTo(n+this.config.markerRadius,c).lineTo(l,c).build()),s.append("path").attr("class","railroad-line").attr("d",new k().moveTo(l+h.dimensions.width,c).lineTo(l+h.dimensions.width+10-this.config.markerRadius,c).build()),{height:Math.max(40,x+h.dimensions.height+this.config.padding*2),width:l+h.dimensions.width+10+this.config.markerRadius}}renderDiagram(i){let o=this.config.padding,s=0;for(let a of i){let n=this.renderRule(a,o);o+=n.height+this.config.verticalSeparation,s=Math.max(s,n.width)}return{width:s+this.config.padding*2,height:o+this.config.padding}}},I=e((i,o,s)=>{S(i,o.height,o.width,s),i.attr("viewBox",`0 0 ${o.width} ${o.height}`)},"configureRailroadSvgSize"),pe=e((i,o,s)=>{t.debug(`[Railroad] Rendering diagram
`+i);try{let a=_(o);a.attr("class","railroad-diagram");let l=u().railroad?.useMaxWidth??!0,T=D.getRules();if(t.debug(`[Railroad] Rendering ${T.length} rules`),T.length===0){t.warn("[Railroad] No rules to render"),I(a,{height:100,width:200},l);return}let c=new he(a,P()).renderDiagram(T);I(a,c,l),t.debug("[Railroad] Render complete")}catch(a){throw t.error("[Railroad] Render error:",a),a}},"draw"),Ge={draw:pe};
export{D,je,Ge};
