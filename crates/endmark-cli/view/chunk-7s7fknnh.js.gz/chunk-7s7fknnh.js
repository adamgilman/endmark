import{Hn}from"./chunk-wszrcpxc.js";export{Hn as createEventModelingServices};
