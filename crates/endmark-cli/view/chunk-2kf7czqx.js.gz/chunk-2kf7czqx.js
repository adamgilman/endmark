import{Nn}from"./chunk-dtn33v35.js";export{Nn as createTreemapServices};
