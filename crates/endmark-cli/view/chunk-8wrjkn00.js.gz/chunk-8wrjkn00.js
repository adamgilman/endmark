import{e}from"./chunk-vf1hkwxg.js";import"./chunk-72kqhbbq.js";import{qn,Wn}from"./chunk-9s9nfpnp.js";import"./chunk-8bhfpv1a.js";import"./chunk-eedwabgv.js";import"./chunk-s329w4ag.js";var r=e((t)=>`${qn(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),o=r,D=Wn({styles:o});export{D as diagram};
