import{e}from"./chunk-bdqnwth2.js";import"./chunk-06vypk61.js";import{qn,Wn}from"./chunk-skr795yy.js";import"./chunk-6hhq72k1.js";import"./chunk-5vb5sfcw.js";import"./chunk-a9pm6mnx.js";var r=e((t)=>`${qn(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),o=r,D=Wn({styles:o});export{D as diagram};
