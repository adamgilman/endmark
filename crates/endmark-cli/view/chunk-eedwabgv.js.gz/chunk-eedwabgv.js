import{e,a}from"./chunk-vf1hkwxg.js";var W=e((o,t)=>{let n;if(t==="sandbox")n=a("#i"+o);return(t==="sandbox"?a(n.nodes()[0].contentDocument.body):a("body")).select(`[id="${o}"]`)},"getDiagramElement");
export{W};
