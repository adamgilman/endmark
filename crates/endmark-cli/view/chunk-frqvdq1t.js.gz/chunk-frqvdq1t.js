import{e}from"./chunk-bdqnwth2.js";function L(c,i){if(c.accDescr)i.setAccDescription?.(c.accDescr);if(c.accTitle)i.setAccTitle?.(c.accTitle);if(c.title)i.setDiagramTitle?.(c.title)}e(L,"populateCommonDb");
export{L};
