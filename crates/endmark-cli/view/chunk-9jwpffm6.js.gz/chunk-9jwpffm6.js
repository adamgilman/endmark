import{Nn}from"./chunk-wszrcpxc.js";export{Nn as createTreemapServices};
