import{$n}from"./chunk-dtn33v35.js";export{$n as createInfoServices};
